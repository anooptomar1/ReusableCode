//
//  ViewController.swift
//  SImpleLoggingClass
//
//  Created by Anoop tomar on 7/30/18.
//  Copyright © 2018 Devtechie. All rights reserved.
//

import UIKit
import LoggingFramework

class ViewController: UIViewController {
    @IBOutlet weak var pView: ProfileView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let logger = Logger()
        logger.log(message: "Fatal error", type: LoggingType.error)
        pView.image = #imageLiteral(resourceName: "blackpanther")
    }

    @IBAction func didTapOnButton(_ sender: UIButton) {
        let alertView = ATAlertView(frame: self.view.bounds)
        alertView.set(alertIconColor: UIColor.orange)
        alertView.set(image: #imageLiteral(resourceName: "blackpanther"))
        alertView.set(headline: "Black Panther Movie")
        alertView.set(subheading: "Story about wakanda and its king.")
        view.addSubview(alertView)
    }
    
    @IBAction func newButtonTapped(_ sender: UIButton) {
        var stvc = SimpleTableViewController()
        self.present(stvc, animated: true, completion: nil)
    }
}

