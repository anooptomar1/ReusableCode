//
//  ProfileView.swift
//  LoggingFramework
//
//  Created by Anoop tomar on 7/31/18.
//  Copyright © 2018 Devtechie. All rights reserved.
//

import UIKit

public class ProfileView: UIView {
    
    @IBInspectable
    public var image: UIImage? {
        didSet {
            if let image = image {
                profileImage.image = image
            }
        }
    }
    
    lazy var profileImage: UIImageView =  {
        let v = UIImageView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.contentMode = .scaleToFill
        return v
    }()

    public override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupView()
    }

    func setupView() {
        addSubview(profileImage)
        NSLayoutConstraint.activate([
            profileImage.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 10),
            profileImage.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -10),
            profileImage.topAnchor.constraint(equalTo: self.topAnchor, constant: 10),
            profileImage.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: -10)
            ])
    }
    
    public override func layoutSubviews() {
        super.layoutSubviews()
        self.profileImage.layer.cornerRadius = self.profileImage.bounds.size.width / 2
        self.profileImage.clipsToBounds = true
    }
}
