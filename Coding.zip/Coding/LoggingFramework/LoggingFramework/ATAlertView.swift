//
//  ATAlertView.swift
//  LoggingFramework
//
//  Created by Anoop tomar on 8/3/18.
//  Copyright © 2018 Devtechie. All rights reserved.
//

import UIKit

@IBDesignable
public class ATAlertView: UIView {

    @IBOutlet private weak var iconView: UIView!
    @IBOutlet private weak var iconImage: UIImageView!
    @IBOutlet private weak var headingLabel: UILabel!
    @IBOutlet private weak var subheadingLabel: UILabel!
    
    let nibName = "ATAlertView"
    var contentView: UIView!
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupView()
    }
    
    public func set(alertIconColor color: UIColor) {
        self.iconView.layer.backgroundColor = color.cgColor
    }
    
    public func set(image: UIImage) {
        self.iconImage.image = image
    }
    
    public func set(headline text: String) {
        self.headingLabel.text = text
    }
    
    public func set(subheading text: String) {
        self.subheadingLabel.text = text
    }
    
    
    func setupView() {
        let bundle = Bundle(for: type(of: self))
        let nib = UINib(nibName: self.nibName, bundle: bundle)
        self.contentView = nib.instantiate(withOwner: self, options: nil).first as! UIView
        addSubview(contentView)
        contentView.center = self.center
        contentView.autoresizingMask = []
        contentView.translatesAutoresizingMaskIntoConstraints = true
        
        headingLabel.text = ""
        subheadingLabel.text = ""
        iconView.layer.cornerRadius = 50
        iconView.layer.masksToBounds = true
        iconView.clipsToBounds = true
        iconView.layer.backgroundColor = UIColor.orange.cgColor
        contentView.layer.cornerRadius = 10
        contentView.layer.masksToBounds = true
    }
    
    // part 2 add timer
//    var timer: Timer?
//
//    public override func didMoveToSuperview() {
//        timer = Timer.scheduledTimer(timeInterval: 3.0, target: self, selector: #selector(removeThisView), userInfo: nil, repeats: false)
//    }
//    
//    @objc private func removeThisView() {
//        self.removeFromSuperview()
//    }
    
    // part 3 animation
    
    var timer: Timer?
    
    public override func didMoveToSuperview() {
        self.contentView.transform = CGAffineTransform(scaleX: 0.01, y: 0.01)
        self.contentView.alpha = 0.0
        UIView.animate(withDuration: 0.2, delay: 0.0, usingSpringWithDamping: 0.7, initialSpringVelocity: 1.0, options: UIViewAnimationOptions.curveEaseIn, animations: {
            self.contentView.alpha = 1.0
            self.contentView.transform = CGAffineTransform.identity
        }) { (_) in
            self.timer = Timer.scheduledTimer(timeInterval: 3.0, target: self, selector: #selector(self.removeThisView), userInfo: nil, repeats: false)
        }
    }
    
    @objc private func removeThisView() {
        UIView.animate(withDuration: 0.2, delay: 0.0, usingSpringWithDamping: 0.7, initialSpringVelocity: 1.0, options: UIViewAnimationOptions.curveEaseOut, animations: {
            self.contentView.transform = CGAffineTransform(scaleX: 0.01, y: 0.01)
            self.contentView.alpha = 0.0
        }) { (_) in
            self.removeFromSuperview()
        }
    }
}
