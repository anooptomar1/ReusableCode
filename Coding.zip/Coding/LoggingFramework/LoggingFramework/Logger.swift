//
//  Logger.swift
//  LoggingFramework
//
//  Created by Anoop tomar on 7/30/18.
//  Copyright © 2018 Devtechie. All rights reserved.
//

import Foundation

public enum LoggingType: String {
    
    case error = "Logging error: "
    case info = "Logging info: "
    case warning = "Logging warning: "
    
}

public class Logger {
    
    public init() {}
    
    public func log(message: String, type: LoggingType) {
        print("\(type.rawValue)\(message)")
    }
    
}
