//
//  NewsCell.swift
//  LoggingFramework
//
//  Created by Anoop tomar on 8/19/18.
//  Copyright © 2018 Devtechie. All rights reserved.
//

import UIKit

class NewsCell: UITableViewCell {
    
    var bannerImg: UIImage? {
        didSet {
            if let bannerImg = bannerImg {
                bannerImage.image = bannerImg
            }
        }
    }
    
    var titleText: String? {
        didSet {
            if let titleText = titleText {
                nameLabel.text = titleText
            }
        }
    }
    
    private lazy var bannerImage: UIImageView = {
        let v = UIImageView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.contentMode = .scaleAspectFit
        v.clipsToBounds = true
        return v
    }()
    
    private lazy var nameLabel: UILabel = {
        let v = UILabel()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.font = v.font.withSize(20)
        return v
    }()
    
    func setupView() {
        self.addSubview(bannerImage)
        self.addSubview(nameLabel)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        NSLayoutConstraint.activate([
            self.bannerImage.widthAnchor.constraint(equalToConstant: 100),
            self.bannerImage.heightAnchor.constraint(equalToConstant: 100),
            self.bannerImage.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 10),
            self.bannerImage.topAnchor.constraint(equalTo: self.topAnchor, constant: 10),
            self.bannerImage.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: 10),
            self.nameLabel.leadingAnchor.constraint(equalTo: self.bannerImage.trailingAnchor, constant: 10),
            self.nameLabel.topAnchor.constraint(equalTo: self.topAnchor, constant: 10),
            self.nameLabel.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: 10)
            ])
    }
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.setupView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.setupView()
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
