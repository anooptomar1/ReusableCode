//
//  SimpleTableViewController.swift
//  LoggingFramework
//
//  Created by Anoop tomar on 8/18/18.
//  Copyright © 2018 Devtechie. All rights reserved.
//

import UIKit

public class SimpleTableViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    lazy var tableview: UITableView = {
        let v = UITableView()
        v.translatesAutoresizingMaskIntoConstraints = false
        v.register(NewsCell.self, forCellReuseIdentifier: "cell")
        return v
    }()
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        tableview.delegate = self
        tableview.dataSource = self
        self.view.addSubview(tableview)
        NSLayoutConstraint.activate([
            tableview.leadingAnchor.constraint(equalTo: self.view.leadingAnchor, constant: 0),
            tableview.trailingAnchor.constraint(equalTo: self.view.trailingAnchor, constant: 0),
            tableview.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 0),
            tableview.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: 0)
            ])
    }


    // MARK: UITableViewDelegate
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableview.dequeueReusableCell(withIdentifier: "cell") as! NewsCell
        cell.titleText = "ROW NUMBER: \(indexPath.row)"
        cell.bannerImg = UIImage(named: "sample1", in: Bundle(for: SimpleTableViewController.self), compatibleWith: nil)!
        return cell
    }
    
    public func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    // MARK: UITableViewDataSource
}
