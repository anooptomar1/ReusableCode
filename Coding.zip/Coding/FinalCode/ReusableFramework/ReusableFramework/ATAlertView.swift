//
//  ATAlertView.swift
//  ReusableFramework
//
//  Created by Anoop tomar on 8/12/18.
//  Copyright © 2018 Devtechie. All rights reserved.
//

import UIKit

public class ATAlertView: UIView {

    @IBOutlet private weak var iconImage: UIImageView!
    @IBOutlet private weak var headingLabel: UILabel!
    
    let nibName = "ATAlertView"
    var contentView: UIView!
    
    var timer: Timer?
    
    override public init(frame: CGRect) {
        super.init(frame: frame)
        self.setupView()
    }
    
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.setupView()
    }
    
    public func set(image: UIImage) {
        self.iconImage.image = image
    }
    
    public func set(headline text: String) {
        self.headingLabel.text = text
    }
    
    func setupView() {
        let bundle = Bundle(for: type(of: self))
        let nib = UINib(nibName: nibName, bundle: bundle)
        self.contentView = nib.instantiate(withOwner: self, options: nil).first as! UIView
        addSubview(contentView)
        
        contentView.center = self.center
        contentView.autoresizingMask = []
        contentView.translatesAutoresizingMaskIntoConstraints = true
        contentView.layer.cornerRadius = 10
        contentView.layer.masksToBounds = true
        
        headingLabel.text = ""
    }
    
    public override func didMoveToSuperview() {
        
        self.contentView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
        self.contentView.alpha = 0.0
        
        UIView.animate(withDuration: 0.8, delay: 0.0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.9, options: UIViewAnimationOptions.curveEaseIn, animations: {
            self.contentView.transform = CGAffineTransform.identity
            self.contentView.alpha = 1.0
        }) { (_) in
            self.timer = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(self.removeThisView), userInfo: nil, repeats: false)
        }
        
    }
    
    @objc func removeThisView() {
        UIView.animate(withDuration: 0.8, delay: 0.0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.9, options: UIViewAnimationOptions.curveEaseOut, animations: {
            self.contentView.transform = CGAffineTransform(scaleX: 0.001, y: 0.001)
            self.contentView.alpha = 0.0
        }) { _ in
            self.removeFromSuperview()
        }
        
    }
}
















