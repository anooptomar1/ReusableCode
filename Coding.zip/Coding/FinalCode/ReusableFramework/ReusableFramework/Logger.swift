//
//  Logger.swift
//  ReusableFramework
//
//  Created by Anoop tomar on 8/4/18.
//  Copyright © 2018 Devtechie. All rights reserved.
//

import Foundation

public enum LoggingType: String {
    case error = "Error: "
    case info = "Info: "
    case warning = "Warning: "
}

public class Logger {
    public init() {}
    
    public func log(message: String, type: LoggingType) {
        print("type: \(type.rawValue) message: \(message)")
    }
}
