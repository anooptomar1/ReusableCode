//
//  ViewController.swift
//  ReusableFrameworkTestApp
//
//  Created by Anoop tomar on 8/4/18.
//  Copyright © 2018 Devtechie. All rights reserved.
//

import UIKit
import ReusableFramework

class ViewController: UIViewController {

    @IBOutlet weak var pView: ProfileView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
     
        let logger = Logger()
        logger.log(message: "viewDidLoad called.", type: LoggingType.info)
        
        pView.image = #imageLiteral(resourceName: "blackpanther")
    }
    
    @IBAction func didTapOnButton(_ sender: UIButton) {
        let alertView = ATAlertView(frame: self.view.bounds)
        alertView.set(image: #imageLiteral(resourceName: "blackpanther"))
        alertView.set(headline: "Black Panther")
        self.view.addSubview(alertView)
    }

}

